Tawadrous  Hehmat




#My project contains:

network URL: http://Tawad-WebAp-LFD86SAP0WH1-397416281.us-west-2.elb.amazonaws.com
Diagram URL: https://lucid.app/documents/view/44bba891-9b34-4ed6-916b-e2e38a2abf18


Files:

- Create.sh
-Create.bat
-Update.sh 
-update.bat
-network.yml
-params.json 
-Images 
-Digram