URLS :

1-CloudFront :

https://d2l0wybqejgckg.cloudfront.net



2-Access the website:

http://my-6582-3593-3961-bucket.s3-website-us-east-1.amazonaws.com



3-Access the bucket object via its S3 object URL:

https://my-6582-3593-3961-bucket.s3.amazonaws.com/index.html